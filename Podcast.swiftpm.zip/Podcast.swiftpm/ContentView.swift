import SwiftUI
import Combine

// MARK: - OWNERSHIP
//
//  SEEALL Podcasting Tracker
//  Created by Mr. Stewart
//  © 2026 SEEALL Academy
//
//  Designed & Developed by Mr. Stewart
//

// MARK: - Workflow Stages
enum EpisodeStatus: String, CaseIterable, Identifiable {
    case preProduction = "Pre-Production"
    case production = "Production"
    case postProduction = "Post-Production"
    case upload = "Upload"
    case achieved = "Achieved"
    
    var id: String { rawValue }
}

// MARK: - Model
struct Episode: Identifiable {
    let id = UUID()
    var title: String
    var status: EpisodeStatus
    
    // ✅ Notes added (NEW)
    var notes: String
}

// MARK: - ViewModel
class PodcastViewModel: ObservableObject {
    @Published var episodes: [Episode] = []
    
    func addEpisode(title: String) {
        guard !title.isEmpty else { return }
        withAnimation {
            episodes.append(
                Episode(
                    title: title,
                    status: .preProduction,
                    notes: "" // ✅ start with empty notes
                )
            )
        }
    }
    
    func moveForward(_ episode: Episode) {
        guard let index = episodes.firstIndex(where: { $0.id == episode.id }) else { return }
        let all = EpisodeStatus.allCases
        if let current = all.firstIndex(of: episodes[index].status),
           current < all.count - 1 {
            withAnimation {
                episodes[index].status = all[current + 1]
            }
        }
    }
    
    func moveBackward(_ episode: Episode) {
        guard let index = episodes.firstIndex(where: { $0.id == episode.id }) else { return }
        let all = EpisodeStatus.allCases
        if let current = all.firstIndex(of: episodes[index].status),
           current > 0 {
            withAnimation {
                episodes[index].status = all[current - 1]
            }
        }
    }
    
    func delete(_ episode: Episode) {
        withAnimation {
            episodes.removeAll { $0.id == episode.id }
        }
    }
    
    func episodes(for status: EpisodeStatus) -> [Episode] {
        episodes.filter { $0.status == status }
    }
    
    // ✅ Helper to update notes safely
    func updateNotes(for episode: Episode, text: String) {
        guard let index = episodes.firstIndex(where: { $0.id == episode.id }) else { return }
        episodes[index].notes = text
    }
}

// MARK: - MAIN VIEW
struct ContentView: View {
    
    @StateObject private var viewModel = PodcastViewModel()
    
    // Add Episode
    @State private var showAddSheet = false
    @State private var newTitle = ""
    
    // Info
    @State private var showInfoSheet = false
    
    // Delete (Linux root joke 😄)
    @State private var showDeleteAlert = false
    @State private var passwordInput = ""
    @State private var episodeToDelete: Episode?
    
    @FocusState private var focusedEpisodeID: UUID?
    var body: some View {
        NavigationView {
            TabView {
                
                // MARK: WORKFLOW PAGE
                ZStack {
                    backgroundView
                    
                    ScrollView(.horizontal) {
                        HStack(alignment: .top, spacing: 16) {
                            
                            Spacer(minLength: 100)
                            
                            ForEach(
                                EpisodeStatus.allCases.filter { $0 != .achieved }
                            ) { status in
                                columnView(for: status)
                                    .fixedSize(horizontal: true, vertical: false)
                            }
                            
                            Spacer(minLength: 100)
                        }
                        .padding(.vertical)
                    }
                }
                .tabItem {
                    Label("Workflow", systemImage: "rectangle.3.group")
                }
                
                // MARK: ACHIEVED PAGE
                ZStack {
                    backgroundView
                    
                    ScrollView {
                        columnView(for: .achieved)
                            .padding()
                    }
                }
                .tabItem {
                    Label("Achieved", systemImage: "checkmark.seal")
                }
            }
            .navigationTitle("SEEALL Podcasting/Video Workflow")
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    
                    Button {
                        showAddSheet = true
                    } label: {
                        Image(systemName: "plus")
                    }
                    
                    Button {
                        showInfoSheet = true
                    } label: {
                        Image(systemName: "info.circle")
                    }
                }
            }
            
            // Delete Alert
            .alert("Root Access Required", isPresented: $showDeleteAlert) {
                SecureField("Enter password", text: $passwordInput)
                Button("Cancel", role: .cancel) {
                    passwordInput = ""
                }
                Button("Delete", role: .destructive) {
                    if passwordInput == "root",
                       let episode = episodeToDelete {
                        viewModel.delete(episode)
                    }
                    passwordInput = ""
                }
            }
            
            // Add Episode Sheet
            .sheet(isPresented: $showAddSheet) {
                NavigationView {
                    VStack(spacing: 20) {
                        TextField("Enter episode title", text: $newTitle)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding()
                        
                        Button("Add Episode") {
                            viewModel.addEpisode(title: newTitle)
                            newTitle = ""
                            showAddSheet = false
                        }
                        
                        Spacer()
                    }
                    .padding()
                    .navigationTitle("New Episode")
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Cancel") {
                                newTitle = ""
                                showAddSheet = false
                            }
                        }
                    }
                }
            }
            
            // Info Sheet
            .sheet(isPresented: $showInfoSheet) {
                NavigationView {
                    VStack(spacing: 16) {
                        
                        Text("SEEALL Podcasting/Video Workflow")
                            .font(.title2)
                            .fontWeight(.semibold)
                        
                        Text("Alpha 1")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        Text("Designed & Developed by")
                            .foregroundColor(.secondary)
                        
                        Text("Mr. Stewart")
                            .font(.headline)
                        
                        Text("© 2026 SEEALL Academy")
                            .foregroundColor(.secondary)
                        
                        Link(
                            "seeallacademy.com",
                            destination: URL(string: "https://seeallacademy.com")!
                        )
                        
                        Spacer()
                        
                        Text("Powered by curiosity, the desire to learn, and the need for coffee")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                            .padding(.bottom, 8)
                    }
                    .padding()
                    .navigationTitle("About")
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Done") {
                                showInfoSheet = false
                            }
                        }
                    }
                }
            }
        }
        // ✅ iPad layout fix
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    // MARK: - Background
    private var backgroundView: some View {
        LinearGradient(
            colors: [
                Color(red: 0.0, green: 0.2, blue: 0.5),
                .white
            ],
            startPoint: .top,
            endPoint: .bottom
        )
        .ignoresSafeArea()
    }
    
    // MARK: - Column View
    private func columnView(for status: EpisodeStatus) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            
            Text(status.rawValue)
                .font(.headline)
                .foregroundColor(.white)
            
            ScrollView {
                ForEach(viewModel.episodes(for: status)) { episode in
                    episodeCard(episode, status: status)
                }
            }
        }
        .frame(width: 240)
        .padding(8)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.white.opacity(0.15))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.white.opacity(0.6), lineWidth: 2)
        )
    }
    
    // MARK: - Episode Card (✅ NOTES ADDED, STYLE PRESERVED)
    private func episodeCard(_ episode: Episode, status: EpisodeStatus) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            
            Text(episode.title)
                .font(.headline)
            
            // ✅ Notes area
            TextEditor(
                text: Binding(
                    get: { episode.notes },
                    set: { newValue in
                        viewModel.updateNotes(for: episode, text: newValue)
                    }
                )
            )
            .frame(minHeight: 60)
            .padding(4)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(6)
            .font(.subheadline)
            
            HStack {
                if status != .preProduction {
                    Button("←") {
                        viewModel.moveBackward(episode)
                    }
                }
                
                if status != .achieved {
                    Button(status == .upload ? "Archive" : "→") {
                        viewModel.moveForward(episode)
                    }
                }
            }
            
            if status == .achieved {
                Button("Delete", role: .destructive) {
                    episodeToDelete = episode
                    showDeleteAlert = true
                }
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(.secondarySystemBackground))
                .shadow(radius: 3)
        )
        .padding(.vertical, 4)
    }
}

// MARK: - Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
